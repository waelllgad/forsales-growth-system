export interface Company {
  id: string;
  name: string;        // اسم الشركة
  activity: string;    // النشاط التجاري
  city: string;        // المدينة
  website: string;     // الموقع الإلكتروني
  email: string;       // البريد الإلكتروني
  phone: string;       // رقم الهاتف
  url: string;         // رابط صفحة الشركة
  contactPerson?: string; // اسم المسؤول
  firstContactDate?: string; // تاريخ أول تواصل
  contactCount: number; // عدد مرات التواصل
  status: CompanyStatus; // حالة الشركة
  createdAt: string;
}

export type CompanyStatus =
  | 'Not Contacted'
  | 'Invitation Sent'
  | 'Opened Email'
  | 'Account Activated'
  | 'Posted Ad'
  | 'Became Paid Client'
  | 'Declined';

export interface OutreachLog {
  id: string;
  companyId: string;
  companyName: string;
  email: string;
  subject: string;
  body: string;
  status: 'Success' | 'Failed' | 'Pending';
  sentAt: string;
}

export interface OutreachSettings {
  dailyLimit: number;
  smtpHost: string;
  smtpPort: number;
  smtpUser: string;
  smtpPass: string;
  emailTemplateSubject: string;
  emailTemplateBody: string;
}

export interface CollectorState {
  isCollecting: boolean;
  category: string;
  city: string;
  progress: number; // 0 to 100
  logs: string[];
  collectedCount: number;
}

export interface OutreachState {
  isRunning: boolean;
  progress: number;
  totalInQueue: number;
  sentCount: number;
  successCount: number;
  failedCount: number;
  logs: string[];
}
