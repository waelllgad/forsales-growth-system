import React, { useState, useEffect, useRef } from "react";
import {
  Building2,
  Mail,
  Search,
  Filter,
  Plus,
  Trash2,
  Play,
  Pause,
  Square,
  Settings,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Upload,
  Download,
  AlertCircle,
  RotateCcw,
  Sparkles,
  Check,
  ExternalLink,
  User,
  MapPin,
  Building,
  Activity,
  ChevronDown,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Company, CompanyStatus, OutreachLog, OutreachSettings, CollectorState, OutreachState } from "./types";

export default function App() {
  // Navigation & Tabs
  const [activeTab, setActiveTab] = useState<"crm" | "collector" | "outreach">("crm");

  // State
  const [companies, setCompanies] = useState<Company[]>([]);
  const [logs, setLogs] = useState<OutreachLog[]>([]);
  const [settings, setSettings] = useState<OutreachSettings | null>(null);
  
  // App States
  const [collector, setCollector] = useState<CollectorState>({
    isCollecting: false,
    category: "Bakeries & Restaurants",
    city: "Manchester",
    progress: 0,
    logs: [],
    collectedCount: 0
  });

  const [outreach, setOutreach] = useState<OutreachState>({
    isRunning: false,
    progress: 0,
    totalInQueue: 0,
    sentCount: 0,
    successCount: 0,
    failedCount: 0,
    logs: []
  });

  // Filters and UI State
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [cityFilter, setCityFilter] = useState<string>("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // New Company Form State
  const [newCompany, setNewCompany] = useState({
    name: "",
    activity: "Information Technology & Software",
    city: "Manchester",
    website: "",
    email: "",
    phone: "",
    url: "",
    contactPerson: "",
    status: "Not Contacted" as CompanyStatus
  });

  // Settings Input State
  const [settingsForm, setSettingsForm] = useState<OutreachSettings | null>(null);

  // Custom Input for scraper
  const [customCategory, setCustomCategory] = useState("Bakeries & Restaurants");
  const [customCity, setCustomCity] = useState("Manchester");

  // Timers for polling state
  const pollingInterval = useRef<NodeJS.Timeout | null>(null);

  // Show Toast Helper
  const triggerToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Fetch all companies from server
  const fetchCompanies = async () => {
    try {
      const queryParams = new URLSearchParams();
      if (searchTerm) queryParams.append("search", searchTerm);
      if (statusFilter) queryParams.append("status", statusFilter);
      if (cityFilter) queryParams.append("city", cityFilter);

      const res = await fetch(`/api/companies?${queryParams.toString()}`);
      if (res.ok) {
        const text = await res.text();
        try {
          const data = JSON.parse(text);
          setCompanies(data);
        } catch (err) {
          console.error("Invalid JSON from companies:", text.substring(0, 50));
        }
      }
    } catch (e) {
      console.error("Error fetching companies", e);
    }
  };

  // Fetch campaign logs
  const fetchLogs = async () => {
    try {
      const res = await fetch("/api/logs");
      if (res.ok) {
        const text = await res.text();
        try {
          const data = JSON.parse(text);
          setLogs(data);
        } catch (err) {
          console.error("Invalid JSON from logs:", text.substring(0, 50));
        }
      }
    } catch (e) {
      console.error("Error fetching logs", e);
    }
  };

  // Fetch SMTP Settings
  const fetchSettings = async () => {
    try {
      const res = await fetch("/api/settings");
      if (res.ok) {
        const text = await res.text();
        try {
          const data = JSON.parse(text);
          setSettings(data);
          setSettingsForm(data);
        } catch (err) {
          console.error("Invalid JSON from settings:", text.substring(0, 50));
        }
      }
    } catch (e) {
      console.error("Error fetching settings", e);
    }
  };

  // Fetch Background Engines Status
  const fetchEnginesStatus = async () => {
    try {
      // Collector Status
      const colRes = await fetch("/api/collector/status");
      if (colRes.ok) {
        const text = await colRes.text();
        try {
          const colData = JSON.parse(text);
          setCollector(prev => ({
            ...prev,
            isCollecting: colData.isCollecting,
            progress: colData.progress,
            logs: colData.logs,
            collectedCount: colData.collectedCount
          }));
        } catch (err) {
          console.error("Invalid JSON from collector status:", text.substring(0, 50));
        }
      }

      // Outreach Status
      const outRes = await fetch("/api/outreach/status");
      if (outRes.ok) {
        const text = await outRes.text();
        try {
          const outData = JSON.parse(text);
          setOutreach(outData);
        } catch (err) {
          console.error("Invalid JSON from outreach status:", text.substring(0, 50));
        }
      }
    } catch (e) {
      console.error("Error checking background engines", e);
    }
  };

  // On Load and Search/Filter change
  useEffect(() => {
    fetchCompanies();
  }, [searchTerm, statusFilter, cityFilter]);

  useEffect(() => {
    fetchLogs();
    fetchSettings();
    fetchEnginesStatus();

    // Set polling interval for background progress
    pollingInterval.current = setInterval(() => {
      fetchEnginesStatus();
      fetchCompanies();
      fetchLogs();
    }, 2000);

    return () => {
      if (pollingInterval.current) clearInterval(pollingInterval.current);
    };
  }, []);

  // Handle manual addition
  const handleAddCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompany.name) {
      triggerToast("اسم Company مطلوب", "error");
      return;
    }

    try {
      const res = await fetch("/api/companies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCompany)
      });

      if (res.ok) {
        triggerToast("تم إضافة Company Successfully إلى قاعدة البيانات");
        setShowAddModal(false);
        setNewCompany({
          name: "",
          activity: "Information Technology & Software",
          city: "Manchester",
          website: "",
          email: "",
          phone: "",
          url: "",
          contactPerson: "",
          status: "Not Contacted"
        });
        fetchCompanies();
      } else {
        triggerToast("Failed to إضافة Company", "error");
      }
    } catch (e) {
      console.error(e);
      triggerToast("Server connection error", "error");
    }
  };

  // Handle single deletion
  const handleDeleteCompany = async (id: string) => {
    if (!window.confirm("هل أنت متأكد من Delete هذه Company نهائيًا؟")) return;

    try {
      const res = await fetch(`/api/companies/${id}`, { method: "DELETE" });
      if (res.ok) {
        triggerToast("تم Delete Company Successfully");
        fetchCompanies();
      } else {
        triggerToast("Delete failed", "error");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Remove duplicates
  const handleRemoveDuplicates = async () => {
    try {
      const res = await fetch("/api/companies/remove-duplicates", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        triggerToast(`Duplicates cleaned! Removed ${data.removedCount} duplicate companies.`);
        fetchCompanies();
      }
    } catch (e) {
      console.error(e);
      triggerToast("Failed to clean duplicates", "error");
    }
  };

  // Simulate Funnel Progression
  const handleSimulateFunnel = async (id: string) => {
    try {
      const res = await fetch(`/api/companies/simulate-funnel/${id}`, { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        triggerToast(`Simulation: Status changed for [${data.name}] to: "${data.status}"`);
        fetchCompanies();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Start Collection
  const handleStartCollector = async () => {
    try {
      const res = await fetch("/api/collector/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ category: customCategory, city: customCity })
      });

      if (res.ok) {
        triggerToast("Smart data collector launched successfully", "info");
        fetchEnginesStatus();
      } else {
        const err = await res.json();
        triggerToast(err.error || "Failed to start data collector", "error");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Stop Collection
  const handleStopCollector = async () => {
    try {
      const res = await fetch("/api/collector/stop", { method: "POST" });
      if (res.ok) {
        triggerToast("Data collection stopped", "info");
        fetchEnginesStatus();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Start Outreach
  const handleStartOutreach = async () => {
    try {
      const res = await fetch("/api/outreach/start", { method: "POST" });
      if (res.ok) {
        triggerToast("Custom invitation campaign launched", "success");
        fetchEnginesStatus();
      } else {
        const err = await res.json();
        triggerToast(err.error || "Failed to start campaign", "error");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Stop Outreach
  const handleStopOutreach = async () => {
    try {
      const res = await fetch("/api/outreach/stop", { method: "POST" });
      if (res.ok) {
        triggerToast("Sending campaign paused", "info");
        fetchEnginesStatus();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm) return;

    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settingsForm)
      });

      if (res.ok) {
        triggerToast("SMTP and custom template settings saved successfully");
        fetchSettings();
      } else {
        triggerToast("Failed to save settings", "error");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Update company status directly in table
  const handleUpdateStatus = async (id: string, newStatus: CompanyStatus) => {
    try {
      const res = await fetch(`/api/companies/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });

      if (res.ok) {
        triggerToast("Status updated successfully");
        fetchCompanies();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Drag and Drop files to import
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const text = event.target?.result as string;
          // Simple CSV or JSON parser
          let list = [];
          if (file.name.endsWith(".json")) {
            list = JSON.parse(text);
          } else {
            // Very simple CSV parser (name, activity, city, website, email, phone)
            const lines = text.split("\n");
            list = lines.slice(1).map(line => {
              const parts = line.split(",");
              return {
                name: parts[0]?.trim(),
                activity: parts[1]?.trim(),
                city: parts[2]?.trim(),
                website: parts[3]?.trim(),
                email: parts[4]?.trim(),
                phone: parts[5]?.trim(),
              };
            }).filter(item => item.name);
          }

          const res = await fetch("/api/companies/import", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ list })
          });

          if (res.ok) {
            const data = await res.json();
            triggerToast(`Imported ${data.importedCount} Company new companies successfully!`);
            fetchCompanies();
          }
        } catch (err) {
          triggerToast("Invalid file or incorrect format", "error");
        }
      };
      reader.readAsText(file);
    }
  };

  // Export to Excel-compatible UTF-8 CSV with BOM
  const handleExportCSV = () => {
    if (companies.length === 0) {
      triggerToast("No data to export", "error");
      return;
    }

    const headers = ["اسم Company", "Activity", "City", "Website", "Email", "Phone", "Directory Link", "Manager", "Status", "Date Added"];
    const rows = companies.map(c => [
      c.name, c.activity, c.city, c.website, c.email, c.phone, c.url, c.contactPerson || "", c.status, c.createdAt
    ]);

    // UTF-8 BOM representation to ensure perfect Arabic characters display in Microsoft Excel
    const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `ForSales_Growth_Companies_${new Date().toISOString().split("T")[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast("تم تصدير ملف Companies المتوافق مع Excel Successfully");
  };

  // Generate Funnel Statistics
  const totalCount = companies.length;
  const contactedCount = companies.filter(c => c.status !== "Not Contacted" && c.status !== "Declined").length;
  const openedCount = companies.filter(c => ["Opened Email", "Account Activated", "Posted Ad", "Became Paid Client"].includes(c.status)).length;
  const activatedCount = companies.filter(c => ["Account Activated", "Posted Ad", "Became Paid Client"].includes(c.status)).length;
  const adPublishedCount = companies.filter(c => ["Posted Ad", "Became Paid Client"].includes(c.status)).length;
  const paidCount = companies.filter(c => c.status === "Became Paid Client").length;

  const getStatusBadge = (status: CompanyStatus) => {
    switch (status) {
      case "Not Contacted":
        return <span className="bg-slate-800/50 text-slate-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-slate-700/50">Not Contacted</span>;
      case "Invitation Sent":
        return <span className="bg-amber-500/10 text-amber-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-amber-500/20">Invitation Sent</span>;
      case "Opened Email":
        return <span className="bg-sky-500/10 text-sky-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-sky-500/20">Opened Email</span>;
      case "Account Activated":
        return <span className="bg-teal-500/10 text-teal-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-teal-500/20">✅ Account Activated</span>;
      case "Posted Ad":
        return <span className="bg-indigo-500/10 text-indigo-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-indigo-500/20">📢 Posted Ad</span>;
      case "Became Paid Client":
        return <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-emerald-500/20">💷 Paid Plan</span>;
      case "Declined":
        return <span className="bg-rose-500/10 text-rose-400 px-2.5 py-1 rounded-full text-[11px] font-medium border border-rose-500/20">Declined</span>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-600 selection:text-white pb-12" dir="ltr">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-6 left-6 right-6 md:left-auto md:w-96 z-50 shadow-2xl rounded-2xl p-4 border flex items-start gap-3 bg-slate-900 border-slate-800 text-slate-100"
          >
            {toast.type === "success" && <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0 mt-0.5" />}
            {toast.type === "error" && <XCircle className="w-6 h-6 text-rose-500 shrink-0 mt-0.5" />}
            {toast.type === "info" && <Info className="w-6 h-6 text-indigo-500 shrink-0 mt-0.5" />}
            <div>
              <p className="font-semibold text-sm text-slate-100">System Notification</p>
              <p className="text-xs text-slate-400 mt-1">{toast.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <header className="bg-gradient-to-b from-slate-900 to-slate-950 text-white border-b border-slate-800/80 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-6 py-8 flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-3">
              <span className="bg-indigo-600 text-indigo-100 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border border-indigo-500/30 shadow-sm">
                UK
              </span>
              <div className="flex items-center gap-2 text-[11px] font-mono text-emerald-400 bg-emerald-400/10 px-3 py-1 rounded-full border border-emerald-500/10">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                SYSTEM ACTIVE
              </div>
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight mt-3 bg-gradient-to-r from-white via-slate-100 to-indigo-100 bg-clip-text text-transparent">
              ForSales <span className="text-indigo-400">Growth System</span>
            </h1>
            <p className="text-sm text-slate-400 mt-2 font-medium max-w-2xl leading-relaxed">
              The integrated system for collecting small business data, managing smart outreach campaigns, and analyzing sales pipeline growth indicators.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-500/10 transition-all duration-200 flex items-center gap-2 border border-indigo-400/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Company Manually
            </button>
            <button
              onClick={handleExportCSV}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all duration-200 flex items-center gap-2 border border-slate-700 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Export to Excel
            </button>
          </div>
        </div>

        {/* Global Navigation Tabs (Bento Style) */}
        <div className="max-w-7xl mx-auto px-6 pb-6 pt-2">
          <nav className="inline-flex gap-1.5 bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800/80">
            <button
              onClick={() => setActiveTab("crm")}
              className={`px-5 py-2 rounded-xl font-bold text-xs transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                activeTab === "crm"
                  ? "bg-indigo-600 text-white font-extrabold shadow-lg shadow-indigo-600/15"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              CRM & Sales Dashboard
            </button>
            <button
              onClick={() => setActiveTab("collector")}
              className={`px-5 py-2 rounded-xl font-bold text-xs transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                activeTab === "collector"
                  ? "bg-indigo-600 text-white font-extrabold shadow-lg shadow-indigo-600/15"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              Smart Data Collector
              {collector.isCollecting && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span>
              )}
            </button>
            <button
              onClick={() => setActiveTab("outreach")}
              className={`px-5 py-2 rounded-xl font-bold text-xs transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                activeTab === "outreach"
                  ? "bg-indigo-600 text-white font-extrabold shadow-lg shadow-indigo-600/15"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              Outreach Campaign Manager
              {outreach.isRunning && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              )}
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-6 mt-8">
        
        {/* ========================================================= */}
        {/* TAB 1: CRM & METRICS DASHBOARD                            */}
        {/* ========================================================= */}
        {activeTab === "crm" && (
          <div className="space-y-8">
            
            {/* KPI Cards Grid */}
            <section className="grid grid-cols-2 lg:grid-cols-6 gap-4">
              
              <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between hover:border-slate-700 transition duration-150">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-semibold">Companies Targeted</span>
                  <div className="bg-slate-800 p-1.5 rounded-lg"><Building className="w-4 h-4 text-slate-300" /></div>
                </div>
                <div className="mt-4">
                  <span className="text-2xl font-extrabold text-white">{totalCount}</span>
                  <p className="text-[10px] text-slate-500 mt-1">Total Collected</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between hover:border-slate-700 transition duration-150">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-semibold">Sent Invitations</span>
                  <div className="bg-amber-950/40 p-1.5 rounded-lg border border-amber-500/10"><Mail className="w-4 h-4 text-amber-400" /></div>
                </div>
                <div className="mt-4">
                  <span className="text-2xl font-extrabold text-white">{contactedCount}</span>
                  <p className="text-[10px] text-slate-500 mt-1">Percentage {totalCount > 0 ? Math.round((contactedCount/totalCount)*100) : 0}% من Companies</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between hover:border-slate-700 transition duration-150">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-semibold">Opened Messages</span>
                  <div className="bg-sky-950/40 p-1.5 rounded-lg border border-sky-500/10"><Search className="w-4 h-4 text-sky-400" /></div>
                </div>
                <div className="mt-4">
                  <span className="text-2xl font-extrabold text-white">{openedCount}</span>
                  <p className="text-[10px] text-slate-500 mt-1">Percentage Open {contactedCount > 0 ? Math.round((openedCount/contactedCount)*100) : 0}%</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between hover:border-slate-700 transition duration-150">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-semibold">Activated Accounts</span>
                  <div className="bg-teal-950/40 p-1.5 rounded-lg border border-teal-500/10"><CheckCircle2 className="w-4 h-4 text-teal-400" /></div>
                </div>
                <div className="mt-4">
                  <span className="text-2xl font-extrabold text-white">{activatedCount}</span>
                  <p className="text-[10px] text-slate-500 mt-1">Percentage Activation {openedCount > 0 ? Math.round((activatedCount/openedCount)*100) : 0}%</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4 shadow-lg flex flex-col justify-between hover:border-slate-700 transition duration-150">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-semibold">Published Ads</span>
                  <div className="bg-indigo-950/40 p-1.5 rounded-lg border border-indigo-500/10"><Sparkles className="w-4 h-4 text-indigo-400" /></div>
                </div>
                <div className="mt-4">
                  <span className="text-2xl font-extrabold text-white">{adPublishedCount}</span>
                  <p className="text-[10px] text-slate-500 mt-1">Marketing activity for clients</p>
                </div>
              </div>

              <div className="bg-indigo-600 border border-indigo-500 text-white rounded-2xl p-4 shadow-lg shadow-indigo-500/10 flex flex-col justify-between hover:bg-indigo-500 transition duration-150">
                <div className="flex items-center justify-between text-indigo-100">
                  <span className="text-xs font-bold">Paid Plans</span>
                  <div className="bg-white/20 p-1.5 rounded-lg text-white font-extrabold"><span className="text-sm">💷</span></div>
                </div>
                <div className="mt-4">
                  <span className="text-2xl font-black text-white">{paidCount}</span>
                  <p className="text-[10px] text-indigo-100 mt-1">Conversion Rate {totalCount > 0 ? ((paidCount/totalCount)*100).toFixed(1) : 0}%</p>
                </div>
              </div>

            </section>

            {/* Visual Funnel Analysis Chart */}
            <section className="bg-slate-900 border border-slate-800/80 rounded-3xl p-6 shadow-xl">
              <h3 className="text-base font-bold text-slate-100 mb-4">📊 Sales Conversion Funnel</h3>
              <div className="space-y-4">
                
                {/* Collected */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1 text-slate-300"><Building className="w-3.5 h-3.5 text-slate-400" /> Companies Collected</span>
                    <span className="text-slate-400">{totalCount} Company (100%)</span>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-800/40 rounded-full h-3.5 overflow-hidden">
                    <div className="bg-slate-500 h-full rounded-full transition-all duration-500" style={{ width: "100%" }}></div>
                  </div>
                </div>

                {/* Contacted */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1 text-amber-400"><Mail className="w-3.5 h-3.5" /> Sent and Scheduled Invitations</span>
                    <span className="text-amber-400/85">{contactedCount} Invitation ({totalCount > 0 ? Math.round((contactedCount/totalCount)*100) : 0}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-800/40 rounded-full h-3.5 overflow-hidden">
                    <div className="bg-amber-400 h-full rounded-full transition-all duration-500" style={{ width: `${totalCount > 0 ? (contactedCount/totalCount)*100 : 0}%` }}></div>
                  </div>
                </div>

                {/* Opened */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1 text-sky-400"><Search className="w-3.5 h-3.5" /> Opened Messages & Interest</span>
                    <span className="text-sky-400/85">{openedCount} Interested ({totalCount > 0 ? Math.round((openedCount/totalCount)*100) : 0}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-800/40 rounded-full h-3.5 overflow-hidden">
                    <div className="bg-sky-400 h-full rounded-full transition-all duration-500" style={{ width: `${totalCount > 0 ? (openedCount/totalCount)*100 : 0}%` }}></div>
                  </div>
                </div>

                {/* Activated */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1 text-teal-400"><CheckCircle2 className="w-3.5 h-3.5" /> Activated Accounts on Platform</span>
                    <span className="text-teal-400/85">{activatedCount} Account ({totalCount > 0 ? Math.round((activatedCount/totalCount)*100) : 0}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-800/40 rounded-full h-3.5 overflow-hidden">
                    <div className="bg-teal-500 h-full rounded-full transition-all duration-500" style={{ width: `${totalCount > 0 ? (activatedCount/totalCount)*100 : 0}%` }}></div>
                  </div>
                </div>

                {/* Published Ads */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1 text-indigo-400"><Sparkles className="w-3.5 h-3.5" /> Published Marketing Ads</span>
                    <span className="text-indigo-400/85">{adPublishedCount} Ad ({totalCount > 0 ? Math.round((adPublishedCount/totalCount)*100) : 0}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-800/40 rounded-full h-3.5 overflow-hidden">
                    <div className="bg-indigo-500 h-full rounded-full transition-all duration-500" style={{ width: `${totalCount > 0 ? (adPublishedCount/totalCount)*100 : 0}%` }}></div>
                  </div>
                </div>

                {/* Paid */}
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1 text-emerald-400">💷 Subscribed Customers to Paid Plans (Final Goal)</span>
                    <span className="font-bold text-emerald-400">{paidCount} Client ({totalCount > 0 ? Math.round((paidCount/totalCount)*100) : 0}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-800/40 rounded-full h-3.5 overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${totalCount > 0 ? (paidCount/totalCount)*100 : 0}%` }}></div>
                  </div>
                </div>

              </div>
            </section>

            {/* Leads Table Card */}
            <section className="bg-slate-900 border border-slate-800/80 rounded-3xl shadow-xl overflow-hidden">
              <div className="p-6 border-b border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/50">
                <div>
                  <h3 className="text-base font-bold text-slate-100">📋 سجل Companies وخط المبيعات الكامل</h3>
                  <p className="text-xs text-slate-400 mt-0.5">ابحث وقم بتصفية Companies وتحديث الحالات أو Activation المحاكاة السريعة.</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRemoveDuplicates}
                    className="border border-slate-800 hover:border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition flex items-center gap-1"
                    title="إزالة Companies المكررة تلقائيًا بناءً على الاسم أو Email"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                    Clean and Remove Duplicates
                  </button>
                </div>
              </div>

              {/* Advanced Search and Filter controls */}
              <div className="p-6 bg-slate-950 border-b border-slate-800/80 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
                  <input
                    type="text"
                    placeholder="ابحث باسم Company، Activity، البريد..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-4 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none placeholder:text-slate-600"
                  />
                </div>

                <div>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  >
                    <option value="" className="bg-slate-900 text-slate-200">All Statuses</option>
                    <option value="Not Contacted" className="bg-slate-900 text-slate-200">Not Contacted</option>
                    <option value="Invitation Sent" className="bg-slate-900 text-slate-200">Invitation Sent</option>
                    <option value="Opened Email" className="bg-slate-900 text-slate-200">Opened Email</option>
                    <option value="Account Activated" className="bg-slate-900 text-slate-200">✅ Account Activated</option>
                    <option value="Posted Ad" className="bg-slate-900 text-slate-200">📢 Posted Ad</option>
                    <option value="Became Paid Client" className="bg-slate-900 text-slate-200">💷 Became Paid Client</option>
                    <option value="Declined" className="bg-slate-900 text-slate-200">Declined</option>
                  </select>
                </div>

                <div>
                  <select
                    value={cityFilter}
                    onChange={(e) => setCityFilter(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  >
                    <option value="" className="bg-slate-900 text-slate-200">All Cities</option>
                    <option value="Manchester" className="bg-slate-900 text-slate-200">Manchester (Manchester)</option>
                    <option value="London" className="bg-slate-900 text-slate-200">London</option>
                    <option value="Liverpool" className="bg-slate-900 text-slate-200">Liverpool</option>
                    <option value="Birmingham" className="bg-slate-900 text-slate-200">Birmingham</option>
                  </select>
                </div>

                <div className="flex items-center justify-end text-xs text-slate-500 font-medium">
                  Showing {companies.length} out of {totalCount} Company
                </div>
              </div>

              {/* Table Wrapper */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/50 text-slate-400 text-xs border-b border-slate-800">
                      <th className="p-4 font-bold">Company & Activity</th>
                      <th className="p-4 font-bold">City & Contact</th>
                      <th className="p-4 font-bold">Manager Details</th>
                      <th className="p-4 font-bold">Contact Count</th>
                      <th className="p-4 font-bold">Status Current</th>
                      <th className="p-4 font-bold text-center">Simulation & Control Tools</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40 text-xs text-slate-300">
                    {companies.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-12 text-center text-slate-500">
                          <Building className="w-12 h-12 mx-auto text-slate-700 mb-2" />
                          <p className="font-bold">No Companies added currently matching the search criteria.</p>
                          <p className="text-xs mt-1 text-slate-600">Start collecting data using the smart data collector or add a Company manually.</p>
                        </td>
                      </tr>
                    ) : (
                      companies.map((company) => (
                        <tr key={company.id} className="hover:bg-slate-800/20 transition-all duration-150">
                          <td className="p-4">
                            <div className="font-extrabold text-white text-[13px]">{company.name}</div>
                            <div className="text-[11px] text-indigo-400 font-semibold mt-1 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                              {company.activity}
                            </div>
                            {company.website && (
                              <a
                                href={company.website}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[10px] text-slate-500 hover:text-indigo-400 flex items-center gap-0.5 mt-1"
                              >
                                {company.website}
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                          </td>
                          <td className="p-4 space-y-1">
                            <div className="flex items-center gap-1 font-semibold text-slate-200">
                              <MapPin className="w-3.5 h-3.5 text-rose-500" />
                              {company.city}
                            </div>
                            {company.email && <div className="text-slate-400">{company.email}</div>}
                            {company.phone && <div className="text-[10px] text-slate-500">{company.phone}</div>}
                          </td>
                          <td className="p-4">
                            <div className="font-medium text-slate-300">{company.contactPerson || "Unspecified"}</div>
                            {company.url && (
                              <a
                                href={company.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[10px] text-indigo-400 hover:underline mt-1 inline-block"
                              >
                                Show Public Source ↗
                              </a>
                            )}
                          </td>
                          <td className="p-4 text-center">
                            <div className="font-bold text-white text-sm">{company.contactCount}</div>
                            {company.firstContactDate ? (
                              <div className="text-[10px] text-slate-500 mt-0.5 font-mono">First Contact: {company.firstContactDate}</div>
                            ) : (
                              <div className="text-[10px] text-slate-500 mt-0.5">-</div>
                            )}
                          </td>
                          <td className="p-4">
                            <select
                              value={company.status}
                              onChange={(e) => handleUpdateStatus(company.id, e.target.value as CompanyStatus)}
                              className="bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-2 py-1 text-xs outline-none focus:ring-1 focus:ring-indigo-500"
                            >
                              <option value="Not Contacted">Not Contacted</option>
                              <option value="Invitation Sent">Invitation Sent</option>
                              <option value="Opened Email">Opened Email</option>
                              <option value="Account Activated">Account Activated</option>
                              <option value="Posted Ad">Posted Ad</option>
                              <option value="Became Paid Client">Became Paid Client</option>
                              <option value="Declined">Declined</option>
                            </select>
                            <div className="mt-1.5">{getStatusBadge(company.status)}</div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => handleSimulateFunnel(company.id)}
                                className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 font-bold px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1 text-[11px]"
                                title="Change Status automatically to Simulate Interaction for this Client step by step"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                                Simulate Interaction ↗
                              </button>
                              
                              <button
                                onClick={() => handleDeleteCompany(company.id)}
                                className="text-slate-500 hover:text-rose-400 p-2 rounded-lg transition hover:bg-rose-950/20 cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

            </section>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: DATA COLLECTOR                                      */}
        {/* ========================================================= */}
        {activeTab === "collector" && (
          <div className="space-y-8">
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Form Input Card */}
              <div className="bg-slate-900 border border-slate-800/80 rounded-3xl p-6 shadow-xl space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-100">🕵️ معايير تجميع Companies</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Select the Business Activity category and city to start automatic search and collection.
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">Target Business Activity</label>
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      {["Bakeries & Restaurants", "Dental Clinics", "Used Cars", "Information Technology", "Cleaning Services", "Law & Legal"].map((act) => (
                        <button
                          key={act}
                          onClick={() => {
                            setCustomCategory(act);
                          }}
                          className={`p-2 text-xs rounded-xl border text-center font-semibold cursor-pointer transition ${
                            customCategory === act
                              ? "bg-indigo-600 border-indigo-500 text-white font-bold shadow-lg shadow-indigo-600/15"
                              : "border-slate-800 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200 bg-slate-950/20"
                          }`}
                        >
                          {act}
                        </button>
                      ))}
                    </div>
                    <input
                      type="text"
                      value={customCategory}
                      onChange={(e) => setCustomCategory(e.target.value)}
                      placeholder="Or type another custom business activity..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 outline-none placeholder:text-slate-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">Target City</label>
                    <select
                      value={customCity}
                      onChange={(e) => setCustomCity(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs focus:ring-1 focus:ring-indigo-500 outline-none font-semibold text-slate-200"
                    >
                      <option value="Manchester" className="bg-slate-950 text-slate-200">Manchester</option>
                      <option value="London" className="bg-slate-950 text-slate-200">London</option>
                      <option value="Liverpool" className="bg-slate-950 text-slate-200">Liverpool</option>
                      <option value="Birmingham" className="bg-slate-950 text-slate-200">Birmingham</option>
                    </select>
                  </div>

                  {/* API Key info */}
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/60 text-[11px] text-slate-400 space-y-1.5">
                    <div className="flex items-center gap-1 font-bold text-slate-200">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      AI-Powered Data Extractor
                    </div>
                    <p>
                      The system produces complete lists containing websites, managers, and public emails. 
                    </p>
                    <p className="text-[10px] text-slate-500">
                      • If the API key is available, Gemini will handle actual search and filtering. Otherwise, the system accurately simulates a directory search.
                    </p>
                  </div>

                  {/* Actions buttons */}
                  <div className="pt-2">
                    {!collector.isCollecting ? (
                      <button
                        onClick={handleStartCollector}
                        className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm py-3 rounded-xl transition shadow-lg shadow-indigo-600/15 flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Play className="w-4 h-4" />
                        Start Extracting Data
                      </button>
                    ) : (
                      <button
                        onClick={handleStopCollector}
                        className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm py-3 rounded-xl transition shadow-lg shadow-rose-600/15 flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Square className="w-4 h-4" />
                        Pause Process
                      </button>
                    )}
                  </div>

                </div>
              </div>

              {/* Progress & Live logs view */}
              <div className="lg:col-span-2 bg-slate-900 text-slate-100 rounded-3xl p-6 shadow-xl flex flex-col justify-between min-h-[400px]">
                
                {/* Header of Screen */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
                      Live Monitoring Unit for Collection and Simulation
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Compliance rate with terms of use is 100% to avoid bans.</p>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-slate-300 font-mono px-2 py-1 rounded">
                    STATUS: {collector.isCollecting ? "RUNNING" : "IDLE"}
                  </span>
                </div>

                {/* Progress bar info */}
                <div className="my-6 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-slate-300">Overall Collection Progress</span>
                    <span className="text-amber-400 font-mono">{collector.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-400 h-full rounded-full transition-all duration-300"
                      style={{ width: `${collector.progress}%` }}
                    ></div>
                  </div>
                  <p className="text-[11px] text-amber-300/80">
                    ℹ️ Discovered and added {collector.collectedCount} Company new unique companies to CRM so far in this session.
                  </p>
                </div>

                {/* Logs Terminal */}
                <div className="flex-1 bg-black/50 border border-slate-800 rounded-2xl p-4 font-mono text-[11px] text-slate-300 overflow-y-auto space-y-2 max-h-[220px]">
                  {collector.logs.length === 0 ? (
                    <div className="text-slate-500 text-center py-12">
                      &gt;_ Monitoring screen currently empty. Click "Start Extracting Data" to begin operations.
                    </div>
                  ) : (
                    collector.logs.map((log, idx) => (
                      <div key={idx} className="flex gap-2 items-start leading-relaxed">
                        <span className="text-slate-500 shrink-0">[{new Date().toLocaleTimeString()}]</span>
                        <span className="text-slate-100">{log}</span>
                      </div>
                    ))
                  )}
                </div>

                {/* Warning note */}
                <p className="text-[10px] text-slate-500 mt-4 leading-relaxed">
                  ⚠️ Security & Privacy Alert: This program respects terms of use of public directories and does not send intensive or fast requests. The search engine is equipped with smart delays (2-3 seconds) to protect the IP address and ensure data integrity.
                </p>

              </div>

            </div>

            {/* Drag and Drop Lead Importer Area */}
            <section className="bg-slate-900 border border-slate-800/80 rounded-3xl p-8 shadow-xl">
              <h3 className="text-base font-bold text-slate-100 mb-2">📥 Import Companies from External Files (Excel / CSV / JSON)</h3>
              <p className="text-xs text-slate-400 mb-6">Do you have a ready-made company file? Drag or select the file to insert it immediately into your CRM.</p>

              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-8 text-center transition ${
                  dragActive
                    ? "border-indigo-500 bg-indigo-500/10"
                    : "border-slate-800 bg-slate-950/40 hover:bg-slate-950/60"
                }`}
              >
                <div className="max-w-md mx-auto space-y-3 cursor-pointer">
                  <Upload className="w-10 h-10 mx-auto text-indigo-400" />
                  <p className="text-sm font-bold text-slate-200">Drag and drop the file here for direct upload</p>
                  <p className="text-xs text-slate-500 font-medium">Supports .CSV or .JSON files. The file must contain a "Name" column as a primary condition.</p>
                  
                  <label className="inline-block bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 font-semibold text-xs px-4 py-2 rounded-xl shadow-md cursor-pointer transition">
                    Browse file from your device
                    <input
                      type="file"
                      accept=".csv,.json"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          const file = e.target.files[0];
                          const reader = new FileReader();
                          reader.onload = async (event) => {
                            try {
                              const text = event.target?.result as string;
                              let list = [];
                              if (file.name.endsWith(".json")) {
                                list = JSON.parse(text);
                              } else {
                                const lines = text.split("\n");
                                list = lines.slice(1).map(line => {
                                  const parts = line.split(",");
                                  return {
                                    name: parts[0]?.trim(),
                                    activity: parts[1]?.trim(),
                                    city: parts[2]?.trim(),
                                    website: parts[3]?.trim(),
                                    email: parts[4]?.trim(),
                                    phone: parts[5]?.trim(),
                                  };
                                }).filter(item => item.name);
                              }

                              const res = await fetch("/api/companies/import", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ list })
                              });

                              if (res.ok) {
                                const data = await res.json();
                                triggerToast(`Imported ${data.importedCount} Company new companies successfully!`);
                                fetchCompanies();
                              }
                            } catch (err) {
                              triggerToast("Invalid file format", "error");
                            }
                          };
                          reader.readAsText(file);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </section>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3: OUTREACH MANAGER                                   */}
        {/* ========================================================= */}
        {activeTab === "outreach" && (
          <div className="space-y-8">
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Campaign Settings and Template card */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800/80 rounded-3xl p-6 shadow-xl space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-100">✉️ Draft Customized Invitation Template for the Campaign</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Design your message using dynamic tags that are automatically replaced for each company.</p>
                </div>

                {settingsForm && (
                  <form onSubmit={handleSaveSettings} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Email Subject</label>
                      <input
                        type="text"
                        value={settingsForm.emailTemplateSubject}
                        onChange={(e) => setSettingsForm({ ...settingsForm, emailTemplateSubject: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 outline-none font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Invitation Email Content</label>
                      <textarea
                        rows={8}
                        value={settingsForm.emailTemplateBody}
                        onChange={(e) => setSettingsForm({ ...settingsForm, emailTemplateBody: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 outline-none font-mono leading-relaxed"
                      />
                    </div>

                    {/* Tags guide */}
                    <div className="p-3 bg-indigo-950/40 rounded-2xl border border-indigo-900/40 text-[10px] text-indigo-200 flex gap-2">
                      <Sparkles className="w-5 h-5 text-indigo-400 shrink-0" />
                      <div>
                        <span className="font-bold text-indigo-100">Supported Auto-Customization Tags:</span>
                        <div className="flex flex-wrap gap-1.5 mt-1.5 font-mono text-indigo-400">
                          <span className="bg-slate-900 border border-indigo-900/40 px-1 py-0.5 rounded">{"{Company_Name}"}</span>
                          <span className="bg-slate-900 border border-indigo-900/40 px-1 py-0.5 rounded">{"{City}"}</span>
                          <span className="bg-slate-900 border border-indigo-900/40 px-1 py-0.5 rounded">{"{Contact_Person}"}</span>
                          <span className="bg-slate-900 border border-indigo-900/40 px-1 py-0.5 rounded">{"{Activation_Link}"}</span>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-800/80 pt-4">
                      <h4 className="text-xs font-bold text-slate-300 mb-3">⚙️ SMTP Server & Website Email Settings</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-1">SMTP Server (SMTP Host)</label>
                          <input
                            type="text"
                            value={settingsForm.smtpHost}
                            onChange={(e) => setSettingsForm({ ...settingsForm, smtpHost: e.target.value })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-1">SMTP Port</label>
                          <input
                            type="number"
                            value={settingsForm.smtpPort}
                            onChange={(e) => setSettingsForm({ ...settingsForm, smtpPort: Number(e.target.value) })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-1">Username</label>
                          <input
                            type="text"
                            value={settingsForm.smtpUser}
                            onChange={(e) => setSettingsForm({ ...settingsForm, smtpUser: e.target.value })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-1">Daily Message Limit (Avoid Bans)</label>
                          <input
                            type="number"
                            value={settingsForm.dailyLimit}
                            onChange={(e) => setSettingsForm({ ...settingsForm, dailyLimit: Number(e.target.value) })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none font-bold"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end pt-2">
                      <button
                        type="submit"
                        className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl transition cursor-pointer shadow-lg shadow-indigo-600/15"
                      >
                        Save Settings, Template, & SMTP Edits
                      </button>
                    </div>

                  </form>
                )}
              </div>

              {/* Outreach Campaign Status & Live terminal */}
              <div className="bg-slate-900 text-slate-100 rounded-3xl p-6 shadow-xl flex flex-col justify-between space-y-6">
                
                <div>
                  <h3 className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Outreach Engine & Delivery Status
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">Automated cross-communication with live delivery status tracking.</p>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/50">
                    <div className="text-slate-400 text-[9px] font-bold">Total Queued</div>
                    <div className="text-lg font-black mt-1">{outreach.totalInQueue}</div>
                  </div>
                  <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/50">
                    <div className="text-emerald-400 text-[9px] font-bold">Sent Successfully</div>
                    <div className="text-lg font-black mt-1 text-emerald-400">{outreach.successCount}</div>
                  </div>
                  <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/50">
                    <div className="text-rose-400 text-[9px] font-bold">Blacklist / Failed</div>
                    <div className="text-lg font-black mt-1 text-rose-400">{outreach.failedCount}</div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold text-slate-300">
                    <span>Overall Progress of Current Campaign</span>
                    <span className="font-mono text-emerald-400">{outreach.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full rounded-full transition-all duration-300"
                      style={{ width: `${outreach.progress}%` }}
                    ></div>
                  </div>
                </div>

                {/* Campaign Action buttons */}
                <div>
                  {!outreach.isRunning ? (
                    <button
                      onClick={handleStartOutreach}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3 rounded-xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Play className="w-4 h-4" />
                      Start Outreach Campaign & Scheduled Delivery
                    </button>
                  ) : (
                    <button
                      onClick={handleStopOutreach}
                      className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs py-3 rounded-xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Pause className="w-4 h-4" />
                      Pause Campaign
                    </button>
                  )}
                </div>

                {/* Live Outreach Terminal */}
                <div className="flex-1 bg-black/40 border border-slate-800 rounded-2xl p-4 font-mono text-[10px] text-slate-300 space-y-1.5 overflow-y-auto max-h-[150px]">
                  {outreach.logs.length === 0 ? (
                    <div className="text-slate-500 text-center py-8">
                      No active sending activity at the moment.
                    </div>
                  ) : (
                    outreach.logs.map((log, idx) => (
                      <div key={idx} className="flex gap-1.5 items-start">
                        <span className="text-slate-500 shrink-0">✉️</span>
                        <span className="text-slate-200 leading-relaxed">{log}</span>
                      </div>
                    ))
                  )}
                </div>

              </div>

            </div>

            {/* Outreach History Log Card */}
            <section className="bg-slate-900 border border-slate-800/80 rounded-3xl shadow-xl overflow-hidden">
              <div className="p-6 border-b border-slate-800/80 bg-slate-900/50">
                <h3 className="text-base font-bold text-slate-100">📋 Historical Log of Sent Invitation Campaigns</h3>
                <p className="text-xs text-slate-400 mt-0.5">List of the latest outgoing messages delivered from the system.</p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/50 text-slate-400 text-xs border-b border-slate-800">
                      <th className="p-4 font-bold">Receiving Company Name</th>
                      <th className="p-4 font-bold">Email</th>
                      <th className="p-4 font-bold">Message Subject</th>
                      <th className="p-4 font-bold">Date and Time Sent</th>
                      <th className="p-4 font-bold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40 text-xs text-slate-300">
                    {logs.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-12 text-center text-slate-500">
                          No previous sending log yet. Start your first campaign from the sending unit.
                        </td>
                      </tr>
                    ) : (
                      logs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-800/20 transition duration-150">
                          <td className="p-4 font-extrabold text-white">{log.companyName}</td>
                          <td className="p-4 text-slate-400 font-mono">{log.email}</td>
                          <td className="p-4 text-slate-300 max-w-xs truncate">{log.subject}</td>
                          <td className="p-4 text-slate-500">{new Date(log.sentAt).toLocaleString("ar-EG")}</td>
                          <td className="p-4">
                            {log.status === "Success" ? (
                              <span className="bg-emerald-500/10 text-emerald-400 px-2 py-1 rounded text-[10px] font-bold border border-emerald-500/20">✓ Delivery Success</span>
                            ) : (
                              <span className="bg-rose-500/10 text-rose-400 px-2 py-1 rounded text-[10px] font-bold border border-rose-500/20">✗ Failed</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </section>

          </div>
        )}

      </main>

      {/* Manual Company Addition Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 rounded-3xl w-full max-w-lg p-6 shadow-2xl border border-slate-800 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-extrabold text-white">Add New Company Manually to Database</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCompany} className="space-y-4 text-xs text-left">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Company Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Luxury Manchester Bakery"
                  value={newCompany.name}
                  onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none focus:ring-1 focus:ring-indigo-500 placeholder:text-slate-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Business Activity</label>
                  <input
                    type="text"
                    placeholder="e.g., Restaurants & Bakeries"
                    value={newCompany.activity}
                    onChange={(e) => setNewCompany({ ...newCompany, activity: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none placeholder:text-slate-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">City</label>
                  <select
                    value={newCompany.city}
                    onChange={(e) => setNewCompany({ ...newCompany, city: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none"
                  >
                    <optgroup label="England" className="bg-slate-900 text-slate-400 font-bold">
                      <option value="London" className="bg-slate-950 text-slate-200 font-normal">London</option>
                      <option value="Birmingham" className="bg-slate-950 text-slate-200 font-normal">Birmingham</option>
                      <option value="Manchester" className="bg-slate-950 text-slate-200 font-normal">Manchester</option>
                      <option value="Leeds" className="bg-slate-950 text-slate-200 font-normal">Leeds</option>
                      <option value="Sheffield" className="bg-slate-950 text-slate-200 font-normal">Sheffield</option>
                      <option value="Liverpool" className="bg-slate-950 text-slate-200 font-normal">Liverpool</option>
                      <option value="Bristol" className="bg-slate-950 text-slate-200 font-normal">Bristol</option>
                      <option value="Newcastle" className="bg-slate-950 text-slate-200 font-normal">Newcastle</option>
                    </optgroup>
                    <optgroup label="Germany" className="bg-slate-900 text-slate-400 font-bold">
                      <option value="Berlin" className="bg-slate-950 text-slate-200 font-normal">Berlin</option>
                      <option value="Hamburg" className="bg-slate-950 text-slate-200 font-normal">Hamburg</option>
                      <option value="Munich" className="bg-slate-950 text-slate-200 font-normal">Munich</option>
                      <option value="Cologne" className="bg-slate-950 text-slate-200 font-normal">Cologne</option>
                      <option value="Frankfurt" className="bg-slate-950 text-slate-200 font-normal">Frankfurt</option>
                      <option value="Stuttgart" className="bg-slate-950 text-slate-200 font-normal">Stuttgart</option>
                      <option value="Dusseldorf" className="bg-slate-950 text-slate-200 font-normal">Düsseldorf</option>
                      <option value="Leipzig" className="bg-slate-950 text-slate-200 font-normal">Leipzig</option>
                    </optgroup>
                    <optgroup label="France" className="bg-slate-900 text-slate-400 font-bold">
                      <option value="Paris" className="bg-slate-950 text-slate-200 font-normal">Paris</option>
                      <option value="Marseille" className="bg-slate-950 text-slate-200 font-normal">Marseille</option>
                      <option value="Lyon" className="bg-slate-950 text-slate-200 font-normal">Lyon</option>
                      <option value="Toulouse" className="bg-slate-950 text-slate-200 font-normal">Toulouse</option>
                      <option value="Nice" className="bg-slate-950 text-slate-200 font-normal">Nice</option>
                      <option value="Nantes" className="bg-slate-950 text-slate-200 font-normal">Nantes</option>
                      <option value="Strasbourg" className="bg-slate-950 text-slate-200 font-normal">Strasbourg</option>
                      <option value="Montpellier" className="bg-slate-950 text-slate-200 font-normal">Montpellier</option>
                    </optgroup>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="example@domain.co.uk"
                    value={newCompany.email}
                    onChange={(e) => setNewCompany({ ...newCompany, email: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none placeholder:text-slate-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+44 161 ..."
                    value={newCompany.phone}
                    onChange={(e) => setNewCompany({ ...newCompany, phone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none placeholder:text-slate-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Website</label>
                  <input
                    type="url"
                    placeholder="https://example.co.uk"
                    value={newCompany.website}
                    onChange={(e) => setNewCompany({ ...newCompany, website: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none placeholder:text-slate-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Company Page / Yell Directory Link</label>
                  <input
                    type="url"
                    placeholder="https://www.yell.com/biz/..."
                    value={newCompany.url}
                    onChange={(e) => setNewCompany({ ...newCompany, url: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none placeholder:text-slate-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Contact Person Name (Manager)</label>
                <input
                  type="text"
                  placeholder="e.g., Alex Hunter"
                  value={newCompany.contactPerson}
                  onChange={(e) => setNewCompany({ ...newCompany, contactPerson: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-3 py-2 outline-none placeholder:text-slate-600"
                />
              </div>

              <div className="flex justify-end gap-2 border-t border-slate-800 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold px-4 py-2 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2 rounded-xl cursor-pointer shadow-lg shadow-indigo-600/15"
                >
                  Save and Add Data
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

    </div>
  );
}
